#. Go to your home page.
#. Enable or disable *Customize > Footer Copyright > Remove Odoo Promotional
   Link* at your will. It should be enabled by default.
