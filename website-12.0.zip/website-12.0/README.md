[![Runbot Status](https://runbot.odoo-community.org/runbot/badge/flat/186/12.0.svg)](https://runbot.odoo-community.org/runbot/repo/github-com-oca-website-186)
[![Build Status](https://travis-ci.org/OCA/website.svg?branch=12.0)](https://travis-ci.org/OCA/website)
[![Coverage Status](https://codecov.io/gh/OCA/website/branch/12.0/graph/badge.svg)](https://codecov.io/gh/OCA/website)

Odoo modules for website builder
================================

Includes modules that expand official website modules and include:

* More functionality for the website builder.
* More building blocks with pre-configured data (snippets).
* Tools for the website environment.
* and more...


