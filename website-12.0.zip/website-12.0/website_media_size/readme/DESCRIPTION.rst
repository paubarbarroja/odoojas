This module shows the size of the media in the media selector (only for media that was uploaded).
