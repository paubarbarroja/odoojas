To use this module, you need to:

#. Go to the media selector
#. You'll see the size in kB in the left top corner of the media item
