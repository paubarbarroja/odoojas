First of all you must obtain
a ReCaptcha key from `Google <http://www.google.com/recaptcha/admin>`_

**Global setup**

* Add site key to `recaptcha.key.site` system parameter
* Add secret key to `recaptcha.key.secret` system parameter

**Single website setup**

* Go to website settings
* Set site key and secret key
