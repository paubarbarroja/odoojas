* Dave Lasley <dave@laslabs.com>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Simone Orsi <simone.orsi@camptocamp.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Cristina Martin R.
  * Jairo Llopis
