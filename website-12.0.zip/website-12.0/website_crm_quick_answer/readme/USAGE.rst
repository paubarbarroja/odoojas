To use this module, you need to:

Have an email address in your main company. It will be used as sender address.
