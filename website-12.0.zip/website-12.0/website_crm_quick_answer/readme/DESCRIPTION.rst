This module was written to extend the functionality of the website contact form
to support sending the interested contact an automatic welcome email and allow
you to customize it.
