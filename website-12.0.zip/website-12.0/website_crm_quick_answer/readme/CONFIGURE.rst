To configure this module, you need to:

#. Go to **Settings > Technical > Automation > Automated actions > Quick response
   to website contact form** and edit anything there.

Quicker way to just change the email template (something that most likely you
will want to do):

#. Go to **Settings > Technical > Email > Templates**
#. Edit the template called *Quick response to website contact form*.
