This module extends the functionality of website links to support smooth
scrolling and allow you to have it for free and with zero configuration.
