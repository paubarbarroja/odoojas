* Add option to smooth when changing page.
