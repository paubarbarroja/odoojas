You might be interested in the module ``website_snippet_anchor``, that lets you
assign anchors and link to them easily, but it is not required.
