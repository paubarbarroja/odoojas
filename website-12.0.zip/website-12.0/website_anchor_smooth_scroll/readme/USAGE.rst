To use this module, you need to:

#. Go to any website view.
#. Create any link whose URL starts with ``#``.
#. Save.
#. Click on it.
