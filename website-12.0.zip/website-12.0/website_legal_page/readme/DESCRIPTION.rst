This module was written to provide common legal pages needed in any website:

* **Legal advice**: Website proprietary and disclaimers
* **Terms of use**: Which services website offers and legal restrictions applied to them
* **Privacy policy**: Company privacy policy applied to user data collected through the website
