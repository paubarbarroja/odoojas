Install some other addon that provides ``website_form`` support to
benefit from this one's features. Hints:

* ``website_crm``
* ``website_form_project``
* ``website_hr_recruitment``
* ``website_sale``
