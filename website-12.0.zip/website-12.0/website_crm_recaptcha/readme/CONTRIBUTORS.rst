* Dave Lasley <dave@laslabs.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Cristina Martin R.
  * Jairo Llopis
