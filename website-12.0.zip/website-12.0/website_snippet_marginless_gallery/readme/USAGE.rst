To use this module, you need to:

* Edit any page in your website.
* Go to **Insert blocks > Features**.
* Drag the **Marginless Gallery** snippet anywhere in your page.

To change images, you need to:

* Select any image block in the snippet you just created.
* Go to **Customize > Background** and choose any background you want.

* Backgrounds will be centered and cover the whole element in any layout.
