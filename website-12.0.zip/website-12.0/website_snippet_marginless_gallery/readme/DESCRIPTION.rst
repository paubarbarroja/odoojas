This module extends the functionality of the website module to add a new
snippet that forms a marginless gallery and allow you to create a grid of
photos that have no spaces between themselves.
