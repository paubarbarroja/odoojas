This is a technical module and have no graphical interface whatsoever.
