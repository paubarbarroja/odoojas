To use this module, you need to:

* Edit any web page.
* Go to **Insert Blocks > Big Buttons**.
* Drag it anywhere.

You can edit the link anywhere on the button.
