This module was written to extend the functionality of website to support
inserting a block with a "like" and "not like" button and allow you to
customize their links, to provide a better UX for your visitors.
