To use this module, you need to:

#. Log in.
#. Go to your homepage.
#. Go to **Customize** menu.
#. Enable **Breadcrumbs** (it is enabled by default).

* If you want to use this module in a theme but you do not like where it is
  rendered, you can simply disable it in the top menu and add in you own
  layout a ``<t t-call="website_breadcrumb.breadcrumb"/>`` element.
