This module allows you to have breadcrumbs in any page of your website.
But if an URL is not present in a menu (as indicated in the Configuration
section), no breadcrumbs will display.
