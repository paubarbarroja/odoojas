from . import test_lazy_load_image
