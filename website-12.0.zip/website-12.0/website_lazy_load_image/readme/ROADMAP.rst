* Lazy load background images (background-image)
