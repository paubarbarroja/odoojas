This module loads images on the website lazy which means
images are loaded only when the visitor scrolls to it (visible in viewport).
This reduces network traffic for your website and your visitors.
