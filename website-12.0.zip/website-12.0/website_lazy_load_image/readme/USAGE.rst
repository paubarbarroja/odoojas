This module automatically lazy loads all images on the page.

To exclude an image for lazy loading:

#. Go to the website editor;
#. click 'Edit';
#. select an image;
#. check the option 'Disable Lazy loading' in the context menu.
