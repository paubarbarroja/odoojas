This module needs no manual configuration.
