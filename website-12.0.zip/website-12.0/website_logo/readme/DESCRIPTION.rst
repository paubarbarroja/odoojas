Load a logo image to be used on website only. This allows to use an internal
company logo (for reports) and a different website logo.
