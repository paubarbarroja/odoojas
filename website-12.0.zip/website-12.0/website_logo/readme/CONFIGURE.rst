To configure this module, you need to:

* Go to "Website -> Configuration -> Settings".
* In the configuration of the selected website there is a 'Logo' label under
  the Favicon.
* Load a logo image in the logo field.
