To use this module, you need to:

#. Go to a website and you will see the logo configured for the website
   instead of the logo of the website's company
