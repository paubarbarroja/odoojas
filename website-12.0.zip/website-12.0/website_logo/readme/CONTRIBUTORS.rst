* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Eslam Amer <esla.amer@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Antonio Espinosa
  * David Vidal
  * Ernesto Tejeda
