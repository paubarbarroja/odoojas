* It would be useful to add the functionality of displaying the company's logo
  on the website when a logo for the website is not specified.