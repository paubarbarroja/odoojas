This module extends the functionality of the website editor to support setting
an anchor to any section of your web page and allow you to link to them very
easily.

Anchors are just the HTML ``id`` attribute, which is commonly used to add it
to any URL and get directly to the element with that anchor, in the form of
https://www.tecnativa.com/#anchor-name.
