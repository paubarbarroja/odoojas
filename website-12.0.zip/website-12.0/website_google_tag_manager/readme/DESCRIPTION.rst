This module allows to configure your Odoo website to support the
`GTM <https://marketingplatform.google.com/about/tag-manager/>`_
tool.
