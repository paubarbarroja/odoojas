To configure this module, you need to:

#. Go to **Website > Configuration > Settings**
#. Search 'Google Tag Manager' option.
#. Fill in your 'Google Tag Manager Key' (e.g. 'GTM-ABCDEF').
