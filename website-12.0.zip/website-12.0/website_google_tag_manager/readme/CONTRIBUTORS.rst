* `Sebastien Alix <sebastien.alix@osiell.com>`_

* `Tecnativa <https://www.tecnativa.com>`__:

  * Cristina Martin R.
