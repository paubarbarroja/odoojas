This module adds the cookie notice, according to the `european cookie law
<http://eur-lex.europa.eu/LexUriServ/LexUriServ.do?uri=CELEX:32002L0058:en:HTML>`_,
to your website.
