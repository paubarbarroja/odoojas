* Before version 8.0.2.0.0 of this module, users had the ability to configure
  the message functionality and appearance from the main company form.

  Now, the message is generated in a view. This means that after upgrading to
  >= 8.0.2.0.0 you will lose your previous customized messages. If you want to
  customize it, please follow steps in the configuration section.
