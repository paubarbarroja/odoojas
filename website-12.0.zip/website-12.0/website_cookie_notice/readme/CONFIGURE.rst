To change the cookie message:

* Go to *Settings > Technical > User Interface > Views*.
* Search for the view called *cookiebanner*.
* Change as you wish. Remember that you will probably lose translations then.

If you are developing a theme for Odoo, remember that this message has the
``cc-cookies`` class. You can style it at will too.
