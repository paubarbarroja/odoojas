To install this module, you need to:

* Install `OCA/server-tools <https://github.com/OCA/server-tools>`_.
