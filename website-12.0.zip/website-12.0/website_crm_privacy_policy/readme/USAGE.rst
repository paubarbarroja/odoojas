Website editors can change easily any text of these pages using website builder
