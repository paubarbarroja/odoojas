Icon
----

Icon based on ```johnny-automatic-scales-of-justice.svg``` from
[Openclipart](https://openclipart.org/detail/26849/scales-of-justice) and
```jetxee-check-sign-and-cross-sign.svg``` from
[Openclipart](https://openclipart.org/detail/11118/check-sign-and-cross-sign)

Thanks to:
* [johnny_automatic](https://openclipart.org/user-detail/johnny_automatic)
* [jetxee](https://openclipart.org/user-detail/jetxee)
