This module was written to add a checkbox to contact us form for user privacy
policy validation

Privacy policy is provided by Website legal page addon (website_legal_page)
