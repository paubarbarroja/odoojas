By default, /robots.txt on an Odoo installation with website module installed will allow indexing by webcrawlers.

This module will overwrite view that generates /robots.txt and won't allow to index.
