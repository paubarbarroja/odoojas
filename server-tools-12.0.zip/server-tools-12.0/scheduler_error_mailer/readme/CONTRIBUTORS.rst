* Sébastien BEAU <sebastien.beau@akretion.com>
* David Beal <bealdavid@gmail.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Sodexis <dev@sodexis.com>
* Achraf Mhadhbi <machraf@bloopark.de>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Cristina Martin R.
