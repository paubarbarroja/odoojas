This module adds the possibility to send an e-mail when a scheduler raises
an error.
