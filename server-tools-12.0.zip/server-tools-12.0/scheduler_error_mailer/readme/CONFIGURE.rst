To configure this module, you need to:

#. Go to Settings -> Technical -> Automation -> Scheduled Actions
#. Choose the scheduled Actions you want to send the error email and select the E-mail Template in the Error E-mail Template field.
