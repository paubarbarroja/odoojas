If you install the module, you will find a tab on the company form allowing
to define the technical user.
