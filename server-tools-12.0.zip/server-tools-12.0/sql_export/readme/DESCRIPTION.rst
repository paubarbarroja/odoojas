Allow to export data in csv files FROM sql requests.
There are some restrictions in the sql query, you can only read datas.
No update, deletion or creation are possible.
A new menu named Export is created.
