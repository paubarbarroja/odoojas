* `Akretion <https://www.akretion.com>`_:

  * Florian da Costa <florian.dacosta@akretion.com>
  * Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
  * Benoît GUILLOT <benoit.guillot@akretion.com>

* `Eficent <https://www.eficent.com>`_:

  * Aaron Henriquez <ahenriquez@eficent.com>
