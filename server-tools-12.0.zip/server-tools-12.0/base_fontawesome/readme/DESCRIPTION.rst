Provide up to date `Fontawesome <http://fontawesome.io/>`_ resources.

Current version: 5.7.1 (the version of this module matches it).
