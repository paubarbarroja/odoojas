Terms used in old api like `pool`, `cr`, `uid` must be removed porting this module in version 12.

This module execute user provided code though a safe_eval, it's unsecure? How mitigate risks should be adressed in future versions of this module.
