* Christoph Giesel <https://github.com/christophlsa>
* Jordi Ballester <jordi.ballester@eficent.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Dave Lasley <dave@laslabs.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Vicent Cubells
  * Ernesto Tejeda
