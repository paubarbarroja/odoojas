12.0.1.0.0 (2019-08-09)
~~~~~~~~~~~~~~~~~~~~~~~

* Add 2 new examples using report action, 1) sale_order 2) partner_list

12.0.1.0.0 (2019-02-24)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of the history
