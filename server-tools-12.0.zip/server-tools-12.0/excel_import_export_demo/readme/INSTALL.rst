To install this module, you need to install **excel_import_export**

Then, simply install **excel_import_export_demo**.
