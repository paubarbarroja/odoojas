12.0.1.0.4 (2019-08-28)
~~~~~~~~~~~~~~~~~~~~~~~

* Fix style sum in footer

12.0.1.0.3 (2019-08-09)
~~~~~~~~~~~~~~~~~~~~~~~

* Add report action for report_type = 'excel'

12.0.1.0.2 (2019-08-07)
~~~~~~~~~~~~~~~~~~~~~~~

* Small fix, to ensure that system parameter 'path_temp_file' (ir.config_parameter) is readable

12.0.1.0.1 (2019-06-24)
~~~~~~~~~~~~~~~~~~~~~~~

* Fix wizard on v12 can't download sample template file - https://github.com/OCA/server-tools/issues/1574

12.0.1.0.0 (2019-02-24)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of the history
